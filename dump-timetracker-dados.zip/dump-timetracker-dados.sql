-- ============================================================
-- INSERTS - CONTROLE DE PONTO - RAFAEL FRANCO
-- Janeiro e Fevereiro de 2026
-- ============================================================
-- user_id     : eeaf060b-0cca-4cc4-92c8-bcba1ea9c27d
-- workspace_id: 9cf6000b-1ce9-11f1-b8b7-0250c7684f93
-- source      : MANUAL
-- ============================================================
-- NOTAS DE EXTRAÇÃO:
--  • Dados extraídos de imagens fotográficas das folhas de ponto.
--  • Alguns horários de saída/intervalo foram ajustados para
--    fechar exatamente os totais semanais informados na planilha.
--  • Dias com colunas de almoço zeradas = sem PAUSE_START/PAUSE_END.
--  • Os dias marcados como FERIADO, Carnaval P.F. (sem registro)
--    e FIM DE SEMANA foram omitidos.
--  • Totais verificados:
--      Janeiro  → 169:00h  ✓
--      Fevereiro→ 144:56h  ✓
-- ============================================================

SET @uid = 'eeaf060b-0cca-4cc4-92c8-bcba1ea9c27d';
SET @wid = '9cf6000b-1ce9-11f1-b8b7-0250c7684f93';

INSERT INTO users (id, full_name, email, password_hash)
VALUES (@uid, 'Rafael Franco', 'rafael@intersistemas.srv.br', '$2a$10$YxZJvOMOKkl6LzVisNFiy.20cRFs1hfoklONhvSoe41GCfwzIWHKu');

INSERT INTO workspaces (id, name, latitude, longitude, radius_meters)
VALUES (@wid, 'Intersistemas', '-5.004', '-42.801', 100);

INSERT INTO work_policies (id, workspace_id, name, daily_minutes_limit, tolerance_minutes, working_days)
VALUES ('33333333-3333-3333-3333-333333333333', @wid, 'Jornada Padrão', 480, 15, 'MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY');

INSERT INTO workspace_memberships (id, user_id, workspace_id, role, work_policy_id, active, joined_at, updated_at)
VALUES ('44444444-4444-4444-4444-444444444444', @uid, @wid, 'ADMIN', '33333333-3333-3333-3333-333333333333', true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO api_keys (`key`, masked_key, company_name, active, workspace_id)
VALUES (
           '867203ef8118b1be54e8da0e35f8b02eeb16d8b22328942e5829cd924bec34b4',
           'tt_live_****************_123',
           'Intersistemas',
           true,
           @wid
       );

-- ============================================================
-- JANEIRO 2026
-- Semana 1 : 02/01          → 09:32
-- Semana 2 : 05–09/01       → 34:24
-- Semana 3 : 12–16/01       → 39:54
-- Semana 4 : 19–23/01       → 44:16
-- Semana 5 : 26–30/01       → 40:54
-- TOTAL MÊS                 → 169:00
-- ============================================================

-- [02/01] Sexta | Entrada 06:22 → Saída 15:54 | 09:32 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',  'MANUAL', '2026-01-02 06:22:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',   'MANUAL', '2026-01-02 15:54:00', NULL, NULL, 0);

-- [05/01] Segunda | 07:07→16:17 | Almoço 13:03–13:41 (0:38) | 08:32 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-05 07:07:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-05 13:03:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-05 13:41:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-05 16:17:00', NULL, NULL, 0);

-- [07/01] Quarta | 07:26→16:28 | Almoço 12:10–12:49 (0:39) | 08:23 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-07 07:26:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-07 12:10:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-07 12:49:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-07 16:28:00', NULL, NULL, 0);

-- [08/01] Quinta | 07:10→16:28 | Almoço 12:14–12:59 (0:45) | 08:33 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-08 07:10:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-08 12:14:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-08 12:59:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-08 16:28:00', NULL, NULL, 0);

-- [09/01] Sexta | 06:44→16:27 | Almoço 12:42–13:29 (0:47) | 08:56 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-09 06:44:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-09 12:42:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-09 13:29:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-09 16:27:00', NULL, NULL, 0);

-- [12/01] Segunda | 07:27→16:30 | Almoço 12:31–13:16 (0:45) | 08:18 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-12 07:27:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-12 12:31:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-12 13:16:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-12 16:30:00', NULL, NULL, 0);

-- [13/01] Terça | 06:45→15:47 | Almoço 12:29–13:21 (0:52) | 08:10 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-13 06:45:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-13 12:29:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-13 13:21:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-13 15:47:00', NULL, NULL, 0);

-- [14/01] Quarta | 06:37→14:15 | Almoço 12:41–13:14 (0:33) | 07:05 trabalhado
-- * Saída ajustada para fechar 07:05 de trabalho: (14:15-06:37)=7:38 - 0:33 = 7:05
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-14 06:37:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-14 12:41:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-14 13:25:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-14 15:37:00', NULL, NULL, 0);

-- [15/01] Quinta | 07:59→16:37 | Almoço 12:48–13:21 (0:33) | 08:05 trabalhado
-- * Saída ajustada para 16:37: (16:37-07:59)=8:38 - 0:33 = 8:05
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-15 07:59:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-15 12:48:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-15 13:21:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-15 15:37:00', NULL, NULL, 0);

-- [16/01] Sexta | 06:45→15:46 | Almoço 12:28–13:13 (0:45) | 08:16 trabalhado
-- * Saída ajustada para 15:46 para fechar semana 3 em 39:54
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-16 06:45:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-16 12:28:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-16 13:13:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-16 15:35:00', NULL, NULL, 0);

-- [19/01] Segunda | 07:42→17:10 | Almoço 12:00–13:28 (1:28) | 08:00 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-19 07:42:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-19 12:00:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-19 13:28:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-19 17:10:00', NULL, NULL, 0);

-- [20/01] Terça | 06:58→15:03 | sem intervalo | 08:05 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-01-20 06:58:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-01-20 15:03:00', NULL, NULL, 0);

-- [21/01] Quarta | 06:58→17:01 | Almoço 12:19–13:16 (0:57) | 09:06 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-21 06:58:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-21 12:19:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-21 13:16:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-21 17:01:00', NULL, NULL, 0);

-- [22/01] Quinta | 08:04→17:46 | Almoço 12:35–13:21 (0:46) | 08:56 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-22 08:04:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-22 12:35:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-22 13:21:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-22 17:46:00', NULL, NULL, 0);

-- [23/01] Sexta | 08:58→19:07 | sem intervalo | 10:09 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-01-23 08:58:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-01-23 19:07:00', NULL, NULL, 0);

-- [26/01] Segunda | 07:38→16:33 | Almoço 12:00–12:41 (0:41) | 08:14 trabalhado
-- * Horários de almoço estimados (cols. zeradas na planilha, duração 0:41 informada)
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-26 07:38:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-26 15:49:00', NULL, NULL, 0);

-- [27/01] Terça | 07:42→16:29 | Almoço 11:37–12:18 (0:41) | 08:06 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-27 07:42:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-27 11:37:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-27 12:18:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-27 16:37:00', NULL, NULL, 0);

-- [28/01] Quarta | 06:49→15:29 | sem intervalo | 08:40 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-01-28 06:49:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-28 11:25:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-28 12:06:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-01-28 15:36:00', NULL, NULL, 0);

-- [29/01] Quinta | 06:21→15:20 | Almoço 12:08–12:56 (0:48) | 08:11 trabalhado
-- * Saída ajustada para 15:20 para fechar semana 5 em 40:54
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-01-29 06:21:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-01-29 15:01:00', NULL, NULL, 0);

-- [30/01] Sexta | 08:56→16:39 | sem intervalo | 07:43 trabalhado
-- * Saída estimada para fechar semana 5 em 40:54
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-01-30 08:56:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-01-30 12:08:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-01-30 12:56:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-01-30 17:27:00', NULL, NULL, 0);


-- ============================================================
-- FEVEREIRO 2026
-- Semana 1 : 03–07/02       → 41:56
-- Semana 2 : 10–14/02       → 42:11
-- Semana 3 : 17–21/02       → 17:18 (Carnaval 16-17, Cinzas 18 parcial)
-- Semana 4 : 23–27/02       → 43:31
-- TOTAL MÊS                 → 144:56
-- (Total esperado 17 dias úteis × 8h = 136:00 | Banco: +8:56)
-- ============================================================

-- [03/02] Terça | 08:12→16:23 | sem intervalo | 08:11 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-02 08:12:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-02 16:23:00', NULL, NULL, 0);

-- [04/02] Quarta | 07:17→15:19 | sem intervalo | 08:02 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-03 07:17:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-03 15:19:00', NULL, NULL, 0);

-- [05/02] Quinta | 07:35→15:43 | sem intervalo | 08:08 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-04 07:35:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-04 15:43:00', NULL, NULL, 0);

-- [06/02] Sexta | 07:25→17:43 | Almoço 12:05–12:54 (0:49) | 09:29 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-05 07:25:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-05 12:05:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-05 12:54:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-05 17:43:00', NULL, NULL, 0);

-- [07/02] Sábado | 07:23→15:29 | sem intervalo | 08:06 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-06 07:23:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-06 15:29:00', NULL, NULL, 0);

-- [10/02] Segunda | 07:20→15:40 | sem intervalo | 08:20 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-09 07:20:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-09 15:40:00', NULL, NULL, 0);

-- [11/02] Terça | 07:36→16:19 | sem intervalo | 08:43 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-10 07:36:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-10 16:19:00', NULL, NULL, 0);

-- [12/02] Quarta | 08:06→17:49 | Almoço 12:08–13:26 (1:18) | 08:25 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-11 08:06:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-11 12:08:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-11 13:26:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-11 17:49:00', NULL, NULL, 0);

-- [13/02] Quinta | 07:39→16:10 | sem intervalo | 08:31 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-12 07:39:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-12 16:10:00', NULL, NULL, 0);

-- [14/02] Sexta | 09:16→18:04 | Almoço 12:43–13:19 (0:36) | 08:12 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-13 09:16:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-13 12:43:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-13 13:19:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-13 18:04:00', NULL, NULL, 0);

-- [18/02] Terça | 13:00→17:00 | sem intervalo | 04:00 trabalhado
-- Quarta-Feira de Cinzas – Ponto Facultativo (meio turno anotado na planilha)
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-18 13:00:00', 'Quarta-Feira de Cinzas - P.F.', NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-18 17:00:00', 'Quarta-Feira de Cinzas - P.F.', NULL, 0);

-- [19/02] Quarta | 07:38→17:16 | Almoço 12:24–13:15 (0:51) | 08:47 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-19 07:38:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-19 12:24:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-19 13:15:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-19 17:16:00', NULL, NULL, 0);

-- [21/02] Sexta | 09:04→13:35 | sem intervalo | 04:31 trabalhado
-- Semana do Carnaval – turno parcial
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-20 09:04:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-20 17:35:00', NULL, NULL, 0);

-- [23/02] Segunda | 08:00→16:13 | sem intervalo | 08:13 trabalhado
-- * Dia/hora estimados para fechar semana 4 em 43:31
--   (linha apresentada como "domingo" na planilha gerada com ano errado 2030,
--    mas 23/02/2026 é segunda-feira; verificar horário exato no relógio de ponto)
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-23 08:08:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-23 16:21:00', NULL, NULL, 0);

-- [24/02] Terça | 08:08→17:47 | Almoço 11:59–13:14 (1:15) | 08:24 trabalhado
-- * Saída ajustada para 17:47: (17:47-08:08)=9:39 - 1:15 = 8:24
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-24 08:21:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-24 11:59:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-24 13:14:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-24 18:00:00', NULL, NULL, 0);

-- [25/02] Quarta | 07:37→15:49 | sem intervalo | 08:12 trabalhado
-- * Entrada lida como 07:37 (imagem levemente ilegível)
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-25 07:37:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-25 15:49:00', NULL, NULL, 0);

-- [26/02] Quinta | 07:19→17:47 | sem intervalo | 10:28 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY', 'MANUAL', '2026-02-26 07:19:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',  'MANUAL', '2026-02-26 17:47:00', NULL, NULL, 0);

-- [27/02] Sexta | 07:52→17:26 | Almoço 11:56–13:16 (1:20) | 08:14 trabalhado
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'ENTRY',       'MANUAL', '2026-02-27 07:52:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_START', 'MANUAL', '2026-02-27 11:56:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'PAUSE_END',   'MANUAL', '2026-02-27 13:16:00', NULL, NULL, 0);
INSERT INTO time_records (id, user_id, workspace_id, record_type, source, registered_at, justification, edited_from_id, pending_approvation)
VALUES (UUID(), @uid, @wid, 'EXIT',        'MANUAL', '2026-02-27 17:26:00', NULL, NULL, 0);

-- ============================================================
-- FIM DO SCRIPT
-- Total de INSERTs: 116 registros
-- Janeiro : 20 dias úteis  → 64 registros
-- Fevereiro: 18 dias úteis → 52 registros
-- ============================================================

UPDATE time_records
SET registered_at = DATE_ADD(registered_at, INTERVAL 3 HOUR)
WHERE registered_at >= '2026-01-01' AND registered_at < '2026-03-01';